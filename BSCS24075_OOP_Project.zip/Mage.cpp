#include "Mage.h"
#include "Character.h"
#include <iostream>

using namespace std;

Mage::Mage(my_str name) : Character(name, 80, 80, 10, 5) {}

void Mage::specialAbility(Character& target)
{
    if (mana < 20) throw "Not enough mana";
    if (!target.isAlive()) throw "Target already defeated";

    mana = mana - 20;
    int damage = (attackPower * 1.5) - (target.getDefense() / 2);
    if (damage < 1) damage = 1;
    cout << name << " casts FIREBALL! (" << damage << " damage)" << endl;
    target.takeDamage(damage);
}