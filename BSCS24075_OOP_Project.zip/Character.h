#pragma once
#ifndef CHARACTER_H
#define CHARACTER_H

#include <iostream>
#include "my_str.h"
#include "vector.h"
#include "StatusEffect.h"
#include "Item.h"

class Item;
class StatusEffect;
class Character;

class Character
{
protected:
    my_str name;
    int health;
    int maxHealth;
    int mana;
    int maxMana;
    int attackPower;
    int defense;
    Dynamic_array<Item*> inventory;
    Dynamic_array<StatusEffect*> activeEffects;

public:
    Character(my_str n, int h, int m, int atk, int def);
    virtual ~Character();
    void addItem(Item* item);
    void useItem(int index);
    void useItem(int index, Character& target);
    void showInventory();
    virtual void attack(Character& target);
    void takeDamage(int damage);
    virtual void specialAbility(Character& target) = 0;
    my_str getName() const;
    int getHealth() const;
    int getMana() const;
    int getDefense() const;
    bool isAlive() const;
    void restoreHealth(int amount);
    void restoreMana(int amount);
    void drainMana(int amount);
    void addStatusEffect(StatusEffect* effect);
    void processStatusEffects();
    int getMaxHealth() const { return maxHealth; }
    int getMaxMana() const { return maxMana; }
    const Dynamic_array<Item*>& getInventory() const { return inventory; }
};

#endif !CHARACTER_H 