#include "Archer.h"
#include <iostream>

using namespace std;

Archer::Archer(my_str name): Character(name, 90, 40, 12, 8) {}
void Archer::specialAbility(Character& target) 
{
    if (mana < 25) throw "Not enough mana";
    if (!target.isAlive()) throw "Target already defeated";

    mana = mana - 25;
    int damage = (attackPower * 1.8) - (target.getDefense() / 2);
    if (damage < 1) damage = 1;
    cout << name << " uses PRECISION SHOT! (" << damage << " damage)" << endl;
    target.takeDamage(damage);
}

