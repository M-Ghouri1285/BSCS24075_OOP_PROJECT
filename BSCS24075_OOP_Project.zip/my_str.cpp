#include <iostream>
#include "my_str.h"

using namespace std;

int my_str::length(const char* s) const
{
    int i = 0;
    while (s[i] != '\0')
    {
        i++;
    }
    return i;
}

my_str::my_str()
{
    str = nullptr;
    len = 0;
    cap = 0;
}

my_str::my_str(const char* ptr)
{
    str = nullptr;
    len = length(ptr);
    cap = len;
    str = new char[len + 1];
    for (int i = 0; i < len; i++)
    {
        str[i] = ptr[i];
    }
    str[len] = '\0';
}

my_str::my_str(const char c, int s)
{
    len = s;
    cap = s;
    str = new char[len + 1];
    for (int i = 0; i < len; i++)
    {
        str[i] = c;
    }
    str[len] = '\0';
}

my_str::my_str(int n)
{
    this->itos(n);
}

my_str my_str::replace_first(char c)
{
    str[0] = c;
    return *this;
}

void my_str::print() const
{
    for (int i = 0; i < len; i++)
    {
        cout << str[i];
    }
    cout << endl;
}

my_str::my_str(const my_str& b)
{
    str = nullptr;
    len = 0;
    cap = 0;
    len = b.len;
    cap = b.cap;
    str = new char[cap + 1];
    for (int i = 0; i < len; i++)
    {
        str[i] = b.str[i];
    }
    str[len] = '\0';
}

my_str& my_str::operator=(const my_str& s)
{
    if (this == &s)
    {
        return *this;
    }
    delete[] str;
    len = s.len;
    cap = s.cap;
    str = new char[len + 1];
    for (int i = 0; i < len; i++)
    {
        str[i] = s.str[i];
    }
    str[len] = '\0';
    return *this;
}

my_str my_str::operator+(const my_str& s) const
{
    my_str res;
    res.len = len + s.len + 1;
    res.cap = res.len + 1;
    res.str = new char[res.cap];
    for (int i = 0; i < len; i++)
    {
        res.str[i] = str[i];
    }
    res.str[len] = ' ';
    for (int i = 0; i < s.len; i++)
    {
        res.str[i + len + 1] = s.str[i];
    }
    res.str[res.len] = '\0';
    return res;
}

int my_str::stoi(const my_str& s)
{
    int res = 0;
    for (int i = 0; i < s.len; i++)
    {
        res = res * 10 + (s.str[i] - '0');
    }
    return res;
}

my_str& my_str::itos(int n)
{
    int temp = n;
    int s = 0;
    if (n == 0) {
        s = 1;
    }
    else {
        while (temp != 0)
        {
            temp = temp / 10;
            s++;
        }
    }
    len = s;
    cap = s;
    str = new char[len + 1];
    temp = n;
    for (int i = s - 1; i >= 0; i--)
    {
        int j = temp % 10;
        str[i] = '0' + j;
        temp = temp / 10;
    }
    str[s] = '\0';
    return *this;
}

my_str my_str::trim()
{
    int i = len - 1;
    while (i >= 0 && (str[i] == '\n' || str[i] == '\t' || str[i] == ' '))
    {
        i--;
    }
    len = i + 1;
    str[len] = '\0';
    i = 0;
    while (i < len && (str[i] == '\n' || str[i] == '\t' || str[i] == ' '))
    {
        i++;
    }
    if (i > 0)
    {
        for (int j = 0; j < len - i; j++)
        {
            str[j] = str[i + j];
        }
        len -= i;
        str[len] = '\0';
    }
    return *this;
}

char my_str::operator[](int i) const
{
    if (i < len)
    {
        return str[i];
    }
    return '\0';
}

char& my_str::operator[](int i)
{
    if (i >= len)
    {
        static char dummy = '\0';
        return dummy;
    }
    return str[i];
}

bool my_str::is_equal(const my_str s)
{
    if (len != s.len)
    {
        return false;
    }
    for (int i = 0; i < len; i++)
    {
        if (str[i] != s.str[i])
        {
            return false;
        }
    }
    return true;
}

bool my_str::is_less(const my_str s)
{
    int min_len = len < s.len ? len : s.len;
    for (int i = 0; i < min_len; i++)
    {
        if (str[i] > s.str[i])
        {
            return false;
        }
        else if (str[i] < s.str[i])
        {
            return true;
        }
    }
    return len < s.len;
}

bool my_str::is_greater(const my_str s)
{
    int min_len = len < s.len ? len : s.len;
    for (int i = 0; i < min_len; i++)
    {
        if (str[i] < s.str[i])
        {
            return false;
        }
        else if (str[i] > s.str[i])
        {
            return true;
        }
    }
    return len > s.len;
}

my_str* my_str::split(char delim, int& count) const
{
    count = 1;
    for (int i = 0; i < len; i++)
    {
        if (str[i] == delim)
        {
            count++;
        }
    }

    my_str* result = new my_str[count];
    int start = 0;
    int current = 0;

    for (int i = 0; i <= len; i++)
    {
        if (i == len || str[i] == delim)
        {
            int sub_len = i - start;
            result[current].str = new char[sub_len + 1];
            result[current].len = sub_len;
            result[current].cap = sub_len;

            for (int j = 0; j < sub_len; j++)
            {
                result[current].str[j] = str[start + j];
            }
            result[current].str[sub_len] = '\0';

            start = i + 1;
            current++;
        }
    }

    return result;
}

my_str* my_str::tokenize(const char* delim, int& count) const
{
    int delim_len = length(delim);
    count = 0;

    bool in_token = false;
    for (int i = 0; i < len; i++)
    {
        bool is_delim = false;
        for (int j = 0; j < delim_len; j++)
        {
            if (str[i] == delim[j])
            {
                is_delim = true;
                break;
            }
        }

        if (!is_delim && !in_token)
        {
            count++;
            in_token = true;
        }
        else if (is_delim)
        {
            in_token = false;
        }
    }

    my_str* tokens = new my_str[count];
    int token_index = 0;
    int token_start = 0;
    in_token = false;

    for (int i = 0; i <= len; i++)
    {
        bool is_delim = (i == len);
        if (i < len)
        {
            for (int j = 0; j < delim_len; j++)
            {
                if (str[i] == delim[j])
                {
                    is_delim = true;
                    break;
                }
            }
        }

        if (!is_delim && !in_token)
        {
            token_start = i;
            in_token = true;
        }
        else if (is_delim && in_token)
        {
            int token_len = i - token_start;
            tokens[token_index].str = new char[token_len + 1];
            tokens[token_index].len = token_len;
            tokens[token_index].cap = token_len;

            for (int j = 0; j < token_len; j++)
            {
                tokens[token_index].str[j] = str[token_start + j];
            }
            tokens[token_index].str[token_len] = '\0';

            token_index++;
            in_token = false;
        }
    }

    return tokens;
}

int* my_str::search_string(const char* delim, int& count) const
{
    int delim_len = length(delim);
    count = 0;

    for (int i = 0; i <= len - delim_len; i++)
    {
        bool match = true;
        for (int j = 0; j < delim_len; j++)
        {
            if (str[i + j] != delim[j])
            {
                match = false;
                break;
            }
        }
        if (match)
        {
            count++;
        }
    }

    int* positions = new int[count];
    int pos_index = 0;

    for (int i = 0; i <= len - delim_len; i++)
    {
        bool match = true;
        for (int j = 0; j < delim_len; j++)
        {
            if (str[i + j] != delim[j])
            {
                match = false;
                break;
            }
        }
        if (match)
        {
            positions[pos_index++] = i;
            i += delim_len - 1;
        }
    }

    return positions;
}

int my_str::find_first(char ch)
{
    for (int i = 0; i < len; i++)
    {
        if (str[i] == ch)
        {
            return i;
        }
    }
    return -1;
}

int my_str::find_first(const my_str& s) const
{
    for (int i = 0; i <= len - s.len; i++)
    {
        bool found = true;
        for (int j = 0; j < s.len; j++)
        {
            if (str[i + j] != s.str[j])
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            return i;
        }
    }
    return -1;
}

int my_str::find_last(char ch)
{
    for (int i = len - 1; i >= 0; i--)
    {
        if (str[i] == ch)
        {
            return i;
        }
    }
    return -1;
}

int my_str::find_last(const my_str& s) const
{
    for (int i = len - s.len; i >= 0; i--)
    {
        bool found = true;
        for (int j = 0; j < s.len; j++)
        {
            if (str[i + j] != s.str[j])
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            return i;
        }
    }
    return -1;
}

int* my_str::find_all(char ch, int& c)
{
    c = 0;
    for (int i = 0; i < len; i++)
    {
        if (str[i] == ch)
        {
            c++;
        }
    }

    int* positions = new int[c];
    int pos_index = 0;

    for (int i = 0; i < len; i++)
    {
        if (str[i] == ch)
        {
            positions[pos_index++] = i;
        }
    }

    return positions;
}

int* my_str::find_all(const my_str& s, int& c) const
{
    c = 0;
    for (int i = 0; i <= len - s.len; i++)
    {
        bool found = true;
        for (int j = 0; j < s.len; j++)
        {
            if (str[i + j] != s.str[j])
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            c++;
        }
    }

    int* positions = new int[c];
    int pos_index = 0;

    for (int i = 0; i <= len - s.len; i++)
    {
        bool found = true;
        for (int j = 0; j < s.len; j++)
        {
            if (str[i + j] != s.str[j])
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            positions[pos_index++] = i;
            i += s.len - 1;
        }
    }

    return positions;
}

void my_str::remove_at(int i)
{
    if (i < 0 || i >= len)
    {
        return;
    }

    for (int j = i; j < len - 1; j++)
    {
        str[j] = str[j + 1];
    }
    len--;
    str[len] = '\0';
}

void my_str::insert_at(int i, char ch)
{
    if (i < 0 || i > len)
    {
        return;
    }

    if (len + 1 > cap)
    {
        cap = (cap == 0) ? 1 : cap * 2;
        char* new_str = new char[cap + 1];
        for (int j = 0; j < i; j++)
        {
            new_str[j] = str[j];
        }
        new_str[i] = ch;
        for (int j = i; j < len; j++)
        {
            new_str[j + 1] = str[j];
        }
        delete[] str;
        str = new_str;
    }
    else
    {
        for (int j = len; j > i; j--)
        {
            str[j] = str[j - 1];
        }
        str[i] = ch;
    }
    len++;
    str[len] = '\0';
}

void my_str::insert_at(int i, const my_str sub)
{
    if (i < 0 || i > len || sub.len == 0)
    {
        return;
    }

    if (len + sub.len > cap)
    {
        cap = len + sub.len;
        char* new_str = new char[cap + 1];
        for (int j = 0; j < i; j++)
        {
            new_str[j] = str[j];
        }
        for (int j = 0; j < sub.len; j++)
        {
            new_str[i + j] = sub.str[j];
        }
        for (int j = i; j < len; j++)
        {
            new_str[j + sub.len] = str[j];
        }
        delete[] str;
        str = new_str;
    }
    else
    {
        for (int j = len - 1; j >= i; j--)
        {
            str[j + sub.len] = str[j];
        }
        for (int j = 0; j < sub.len; j++)
        {
            str[i + j] = sub.str[j];
        }
    }
    len += sub.len;
    str[len] = '\0';
}

void my_str::remove_first(char ch)
{
    int pos = find_first(ch);
    if (pos != -1)
    {
        remove_at(pos);
    }
}

void my_str::remove_last(char ch)
{
    int pos = find_last(ch);
    if (pos != -1)
    {
        remove_at(pos);
    }
}

void my_str::remove_all(char ch)
{
    for (int i = len - 1; i >= 0; i--)
    {
        if (str[i] == ch)
        {
            remove_at(i);
        }
    }
}

void my_str::clear() {
    if (str) {
        delete[] str;
        str = nullptr;
    }
    len = 0;
    cap = 0;
}


my_str::~my_str()
{
    clear();
}

void my_str::upper()
{
    for (int i = 0; i < len; i++)
    {
        if (str[i] >= 'a' && str[i] <= 'z')
        {
            str[i] -= 32;
        }
    }
}

void my_str::lower()
{
    for (int i = 0; i < len; i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
        {
            str[i] += 32;
        }
    }
}

ostream& operator<<(ostream& os, const my_str& s)
{
    for (int i = 0; i < s.len; i++)
    {
        os << s.str[i];
    }
    return os;
}

istream& operator>>(istream& is, my_str& s)
{
    s.clear();

    const int BUFFER_SIZE = 256;
    char buffer[BUFFER_SIZE];

    is >> buffer; 

    s.len = s.length(buffer);
    s.cap = s.len;
    s.str = new char[s.len + 1];

    for (int i = 0; i < s.len; i++)
    {
        s.str[i] = buffer[i];
    }
    s.str[s.len] = '\0';

    return is;
}

