#pragma once
#ifndef MY_STR
#define MY_STR

#include <iostream>
using namespace std;

class my_str
{
private:
    char* str;
    int len;
    int cap;
    int length(const char* s) const;
public:
    my_str();
    my_str(const char* ptr);
    my_str(const char c, int s);
    my_str(int n);
    void print() const;
    my_str(const my_str& b);
    my_str replace_first(char c);
    my_str& operator=(const my_str& s);
    int stoi(const my_str& s);
    my_str& itos(int n);
    my_str trim();
    char operator[](int i) const;
    char& operator[](int i);
    bool is_equal(const my_str s);
    bool is_less(const my_str s);
    bool is_greater(const my_str s);
    my_str* split(char delim, int& count)const;
    my_str* tokenize(const char* delim, int& count) const;
    my_str operator+(const my_str& s) const;
    int* search_string(const char* delim, int& count) const;
    int find_first(char ch);
    int find_first(const my_str& s) const;
    int find_last(char ch);
    int find_last(const my_str& s) const;
    int* find_all(char ch, int& c);
    int* find_all(const my_str& s, int& c) const;
    void remove_at(int i);
    void insert_at(int i, char ch);
    void insert_at(int i, const my_str sub);
    void remove_first(char ch);
    void remove_last(char ch);
    void remove_all(char ch);
    void clear();
    ~my_str();
    void upper();
    void lower();
    friend ostream& operator<<(ostream& os, const my_str& s);
    friend istream& operator>>(istream& is, my_str& s);
};
#endif

