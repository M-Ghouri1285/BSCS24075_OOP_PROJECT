#pragma once
#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H

#include <iostream>
#include <stdexcept> 
#include <utility>   

template <typename T>
class Dynamic_array {
private:
    T* arr;
    int len;
    int cap;

    void double_capacity() {
        int new_cap = (cap == 0) ? 1 : cap * 2;
        T* new_arr = new T[new_cap];

        for (int i = 0; i < len; i++) {
            new_arr[i] = std::move(arr[i]);
        }

        delete[] arr;
        arr = new_arr;
        cap = new_cap;
    }

public:
    //constructors and destructors
    Dynamic_array() : arr(nullptr), len(0), cap(0) {}

    Dynamic_array(int count, const T& value) : len(count), cap(count) {
        arr = new T[cap];
        for (int i = 0; i < len; i++) {
            arr[i] = value;
        }
    }

    Dynamic_array(const Dynamic_array& other) : len(other.len), cap(other.cap) {
        arr = new T[cap];
        for (int i = 0; i < len; i++) {
            arr[i] = other.arr[i];
        }
    }

    ~Dynamic_array() {
        delete[] arr;
    }

    // Operators
    Dynamic_array& operator=(const Dynamic_array& other) {
        if (this != &other) {
            delete[] arr;
            len = other.len;
            cap = other.cap;
            arr = new T[cap];
            for (int i = 0; i < len; i++) {
                arr[i] = other.arr[i];
            }
        }
        return *this;
    }

    T& operator[](int index) {
        return arr[index];
    }

    const T& operator[](int index) const {
        return arr[index];
    }

    bool operator==(const Dynamic_array& other) const {
        if (len != other.len) return false;
        for (int i = 0; i < len; i++) {
            if (arr[i] != other.arr[i]) return false;
        }
        return true;
    }

    bool operator!=(const Dynamic_array& other) const {
        return !(*this == other);
    }

    Dynamic_array operator+(const Dynamic_array& other) const {
        Dynamic_array result;
        result.reserve(len + other.len);
        for (int i = 0; i < len; i++) result.push(arr[i]);
        for (int i = 0; i < other.len; i++) result.push(other.arr[i]);
        return result;
    }

    Dynamic_array& operator+=(const Dynamic_array& other) {
        reserve(len + other.len);
        for (int i = 0; i < other.len; i++) push(other.arr[i]);
        return *this;
    }

    // Modifiers
    void push(const T& value) {
        if (len == cap) double_capacity();
        arr[len++] = value;
    }

    void push(T&& value) {
        if (len == cap) double_capacity();
        arr[len++] = std::move(value);
    }

    void pop() {
        if (len > 0) --len;
    }

    void insert_at(int index, const T& value) {
        if (index < 0 || index > len) throw std::out_of_range("Index out of bounds");
        if (len == cap) double_capacity();

        for (int i = len; i > index; i--) {
            arr[i] = std::move(arr[i - 1]);
        }

        arr[index] = value;
        len++;
    }

    void delete_at(int index) {
        if (index < 0 || index >= len) throw std::out_of_range("Index out of bounds");

        for (int i = index; i < len - 1; i++) {
            arr[i] = std::move(arr[i + 1]);
        }

        len--;
    }

    void reserve(int new_capacity) {
        if (new_capacity > cap) {
            T* new_arr = new T[new_capacity];
            for (int i = 0; i < len; i++) {
                new_arr[i] = std::move(arr[i]);
            }
            delete[] arr;
            arr = new_arr;
            cap = new_capacity;
        }
    }

    void clear() {
        len = 0;
    }

    void swap(Dynamic_array& other) noexcept {
        std::swap(arr, other.arr);
        std::swap(len, other.len);
        std::swap(cap, other.cap);
    }

    void shrink_to_fit() {
        if (len < cap) {
            cap = len;
            T* new_arr = new T[cap];
            for (int i = 0; i < len; i++) {
                new_arr[i] = std::move(arr[i]);
            }
            delete[] arr;
            arr = new_arr;
        }
    }

    void reverse() {
        for (int i = 0; i < len / 2; i++) {
            std::swap(arr[i], arr[len - i - 1]);
        }
    }

    // Accessors
    bool empty() const { return len == 0; }
    int size() const { return len; }
    int capacity() const { return cap; }

    T& at(int index) {
        if (index < 0 || index >= len) throw std::out_of_range("Index out of bounds");
        return arr[index];
    }

    const T& at(int index) const {
        if (index < 0 || index >= len) throw std::out_of_range("Index out of bounds");
        return arr[index];
    }

    T& front() {
        if (len == 0) throw std::out_of_range("Array is empty");
        return arr[0];
    }

    const T& front() const {
        if (len == 0) throw std::out_of_range("Array is empty");
        return arr[0];
    }

    T& back() {
        if (len == 0) throw std::out_of_range("Array is empty");
        return arr[len - 1];
    }

    const T& back() const {
        if (len == 0) throw std::out_of_range("Array is empty");
        return arr[len - 1];
    }

    int find(const T& value) const {
        for (int i = 0; i < len; i++) {
            if (arr[i] == value) return i;
        }
        return -1;
    }

    void print() const {
        for (int i = 0; i < len; i++) {
            std::cout << arr[i] << " ";
        }
        std::cout << "\n";
    }
};

#endif !DYNAMIC_ARRAY_H