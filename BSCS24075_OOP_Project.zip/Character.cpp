#include "Character.h"
#include <iostream>

Character::Character(my_str n, int h, int m, int atk, int def)
    : name(n), health(h), maxHealth(h), mana(m), maxMana(m),
    attackPower(atk), defense(def) {}

Character::~Character()
{
    for (int i = 0; i < inventory.size(); i++) 
    {
        delete inventory[i];
    }
    for (int i = 0; i < activeEffects.size(); i++)
    {
        delete activeEffects[i];
    }
}

void Character::addItem(Item* item)
{
    inventory.push(item);
    cout << "Added " << item->getName() << " to inventory!" << endl;
}

void Character::useItem(int index)
{
    if (index < 0 || index >= inventory.size()) throw "Invalid item slot";
    inventory[index]->use(*this);
    delete inventory[index];
    inventory.delete_at(index);
}

void Character::useItem(int index, Character& target)
{
    if (index < 0 || index >= inventory.size()) throw "Invalid item slot";
    inventory[index]->use(target);
    delete inventory[index];
    inventory.delete_at(index);
}

void Character::showInventory()
{
    cout << endl << "=== " << name << "'s Inventory ===" << endl;
    if (inventory.empty()) throw "Inventory empty";
    for (int i = 0; i < inventory.size(); i++)
    {
        cout << i << ". " << inventory[i]->getName() << " - " << inventory[i]->getDesc() << endl;
    }
}

void Character::attack(Character& target)
{
    int damage = attackPower - (target.getDefense() / 2);
    if (damage < 1) damage = 1;
    cout << name << " attacks " << target.getName() << " for " << damage << " damage!" << endl;
    target.takeDamage(damage);
}

void Character::takeDamage(int damage)
{
    health -= damage;
    if (health <= 0)
    {
        health = 0;
        cout << name << " has been defeated!" << endl;
    }
    else
    {
        cout << name << " now has " << health << "/" << maxHealth << " HP." << endl;
    }
}

void Character::restoreHealth(int amount)
{
    health = health + amount;
    if (health > maxHealth) health = maxHealth;
    cout << name << " now has " << health << "/" << maxHealth << " HP." << endl;
}

void Character::restoreMana(int amount)
{
    mana = mana + amount;
    if (mana > maxMana) mana = maxMana;
    cout << name << " now has " << mana << "/" << maxMana << " MP." << endl;
}

void Character::drainMana(int amount)
{
    if (amount > 0) 
    {
        mana = mana - amount;
        if (mana < 0) mana = 0;
    }
}

my_str Character::getName() const { return name; }
int Character::getHealth() const { return health; }
int Character::getMana() const { return mana; }
int Character::getDefense() const { return defense; }
bool Character::isAlive() const { return health > 0; }

void Character::addStatusEffect(StatusEffect* effect)
{
    activeEffects.push(effect);
    cout << name << " gained " << effect->getName() << " effect!" << endl;
}

void Character::processStatusEffects()
{
    int i = 0;
    while (i < activeEffects.size())
    {     
        activeEffects[i]->onTurnStart(*this);

        if (activeEffects[i]->isExpired()) 
        {
            activeEffects[i]->onExpire(*this);

            delete activeEffects[i];  
            activeEffects.delete_at(i); 
        }
        else 
        {
            i++;  
        }
    }
}

